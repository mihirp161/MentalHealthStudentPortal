DISCLAIMER
-----------
Please note that we have used the "Fake Name Generator"[http://www.fakenamegenerator.com/] to produce believable US addresses. Other data in the file "fake_mentalHealth_data.xlsx" was created using random generation. Any information resemblance to actual persons/place, living , or dead is purely coincidental.
